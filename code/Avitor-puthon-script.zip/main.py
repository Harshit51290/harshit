import random

def choose_multiplier():
    multiplier = random.uniform(1.2, 30)
    # Adjust probability for numbers over 5
    if multiplier > 5:
        if random.random() < 0.2:  # Adjust the probability as needed
            multiplier *= random.uniform(1.2, 5)
    return multiplier

def choose_number():
    number = random.uniform(1, 30)
    # Adjust probability for numbers over 15
    if number > 15:
        if random.random() < 0.3:  # Adjust the probability as needed
            number *= random.uniform(1, 15)
    return number

# Example usage
multiplier_value = choose_multiplier()
number_value = choose_number()

print(f"Chosen Multiplier: {multiplier_value}")
print(f"Chosen Number: {number_value}")
